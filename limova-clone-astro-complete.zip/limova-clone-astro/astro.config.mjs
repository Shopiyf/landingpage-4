import { defineConfig } from 'astro/config';

export default defineConfig({
  // Static output is ideal for Vercel.
  output: 'static',
});
